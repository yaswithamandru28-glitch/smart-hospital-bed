# Smart Hospital Bed Monitoring System (Prototype)

A beginner-friendly Streamlit mini project. **Prototype only: not a medical device and not a diagnostic system.** All hardware is simulated.

## Objective
Let hospital staff identify a patient, monitor vitals, control the bed headrest, detect possible falls and see simple trend-based alerts on one dashboard.

## Features
- RFID simulation (try `RFID1001`, `RFID1002`, `RFID1003`) with patient details
- Headrest control (0-90°) using a simulated linear actuator
- Text-command "voice" control (optional real microphone)
- Fall detection: posture selector (optional OpenCV + MediaPipe camera check)
- Vital signs with configurable Normal / Warning / Critical thresholds
- Trend alerts using linear regression slope (`P002` shows demo alerts)
- Emergency banner and SQLite activity log

## Technologies
Python, Streamlit, SQLite, Pandas, NumPy (optional: OpenCV, MediaPipe, SpeechRecognition)

## Install and run
```
pip install -r requirements.txt
streamlit run app.py
```
Optional extras: `pip install opencv-python mediapipe SpeechRecognition PyAudio`

## Files
| File | Purpose |
|---|---|
| app.py | Dashboard (all 10 sections) |
| patient_data.py | Sample patients and demo trends |
| bed_control.py | Headrest logic + simulated actuator |
| fall_detection.py | Posture check + optional camera pose check |
| prediction.py | Thresholds, classification, trend detection |
| database.py | SQLite: activity log and vitals history |

## Workflow
1. Enter RFID card ID -> patient loaded.
2. Control headrest by buttons or commands. Every action is logged.
3. Set vitals -> status shown -> save to history.
4. Trend analysis runs on recent saved readings.
5. Emergency / nurse call / fall / critical vitals -> red alert + log entry.

## Future hardware integration
Each simulated part has one place to swap in hardware:
- **ESP8266/ESP32**: runs a small HTTP or MQTT server; the Python app sends requests / reads sensor JSON.
- **RFID reader (RC522)**: ESP sends the card UID; replace the sidebar text box with the received UID.
- **Linear actuator**: ESP drives a motor driver (L298N/BTS7960); write a class with `move_up/move_down/stop` that calls the ESP, pass it to `Headrest(actuator=...)`.
- **Temperature sensor (DS18B20/MLX90614), heart-rate + SpO₂ sensor (MAX30102)**: ESP posts readings; replace the sliders with received values and call `database.add_vitals`.
- **Camera**: use `cv2.VideoCapture` frames in `fall_detection.analyze_camera_image`.
- **Buzzer / emergency button**: button input on the ESP triggers `raise_emergency`; Python sends a command to sound the buzzer.

## Future improvements
Login for staff, multi-bed view, SMS/email alerts, better ML models with real data, clinical validation.
