"""SQLite storage for the activity log and vital-sign history."""
import os
import sqlite3
from datetime import datetime, timedelta

import pandas as pd
from patient_data import PATIENTS, SEED_TRENDS, BASE_VITALS

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hospital.db")
VITAL_COLS = ["heart_rate", "temperature", "spo2", "resp_rate"]


def _conn():
    return sqlite3.connect(DB_PATH)


def init_db():
    """Create tables and fill demo vitals the first time the app runs."""
    with _conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS activity_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT, patient_id TEXT,
            category TEXT, message TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS vitals(
            id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT, patient_id TEXT,
            heart_rate REAL, temperature REAL, spo2 REAL, resp_rate REAL)""")
        if c.execute("SELECT COUNT(*) FROM vitals").fetchone()[0] == 0:
            start = datetime.now() - timedelta(minutes=60)
            for rec in PATIENTS.values():
                pid = rec["patient_id"]
                d = SEED_TRENDS[pid]
                for i in range(8):
                    vals = [round(b + i * dv, 1) for b, dv in zip(BASE_VITALS, d)]
                    t = (start + timedelta(minutes=8 * i)).strftime("%Y-%m-%d %H:%M:%S")
                    c.execute("INSERT INTO vitals(time,patient_id,heart_rate,temperature,spo2,resp_rate) "
                              "VALUES(?,?,?,?,?,?)", (t, pid, *vals))


def log_event(patient_id, category, message):
    """Save one event (emergency, fall, voice command, headrest...) to the log."""
    with _conn() as c:
        c.execute("INSERT INTO activity_log(time,patient_id,category,message) VALUES(?,?,?,?)",
                  (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), patient_id, category, message))


def get_log(limit=50):
    with _conn() as c:
        return pd.read_sql_query(
            "SELECT time AS Time, patient_id AS Patient, category AS Type, message AS Details "
            "FROM activity_log ORDER BY id DESC LIMIT ?", c, params=(limit,))


def add_vitals(patient_id, hr, temp, spo2, rr):
    with _conn() as c:
        c.execute("INSERT INTO vitals(time,patient_id,heart_rate,temperature,spo2,resp_rate) "
                  "VALUES(?,?,?,?,?,?)",
                  (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), patient_id, hr, temp, spo2, rr))


def get_vitals_history(patient_id, limit=30):
    """Return the latest readings (oldest first) as a DataFrame."""
    with _conn() as c:
        df = pd.read_sql_query(
            "SELECT time,heart_rate,temperature,spo2,resp_rate FROM vitals "
            "WHERE patient_id=? ORDER BY id DESC LIMIT ?", c, params=(patient_id, limit))
    return df.iloc[::-1].reset_index(drop=True)
