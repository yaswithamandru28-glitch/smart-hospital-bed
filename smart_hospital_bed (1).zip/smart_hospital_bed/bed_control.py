"""Simulated headrest actuator.

To use real hardware later, replace SimulatedActuator with a class that has the
same methods (move_up / move_down / stop) and sends commands to an
Arduino/ESP8266 (serial or HTTP). The rest of the app will not need changes.
"""

MIN_ANGLE, MAX_ANGLE = 0, 90


class SimulatedActuator:
    """Pretend linear actuator. It only prints; a real one would move a motor."""

    def move_up(self):
        print("[ACTUATOR] extending")      # real: serial.write(b"UP\n")

    def move_down(self):
        print("[ACTUATOR] retracting")     # real: serial.write(b"DOWN\n")

    def stop(self):
        print("[ACTUATOR] stopped")        # real: serial.write(b"STOP\n")


class Headrest:
    def __init__(self, actuator=None, step=15):
        self.actuator = actuator or SimulatedActuator()
        self.angle = 0
        self.status = "Headrest Lowered"
        self.step = step  # degrees moved per button press (simulation)

    def raise_up(self):
        if self.angle >= MAX_ANGLE:
            self.status = "Headrest Fully Raised"
            return self.status
        self.actuator.move_up()
        self.angle = min(MAX_ANGLE, self.angle + self.step)
        self.status = "Headrest Raising" if self.angle < MAX_ANGLE else "Headrest Fully Raised"
        return self.status

    def lower(self):
        if self.angle <= MIN_ANGLE:
            self.status = "Headrest Lowered"
            return self.status
        self.actuator.move_down()
        self.angle = max(MIN_ANGLE, self.angle - self.step)
        self.status = "Headrest Lowering" if self.angle > MIN_ANGLE else "Headrest Lowered"
        return self.status

    def stop(self):
        self.actuator.stop()
        self.status = "Headrest Stopped"
        return self.status
