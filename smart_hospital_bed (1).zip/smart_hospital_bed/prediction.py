"""Vital-sign classification and simple trend prediction.
PROTOTYPE ALERTS ONLY - NOT A MEDICAL DIAGNOSTIC SYSTEM."""
import numpy as np

# name: (warn_low, warn_high, crit_low, crit_high) - editable in the sidebar
DEFAULT_THRESHOLDS = {
    "Heart Rate": (55, 100, 40, 130),
    "Temperature": (36.0, 37.8, 35.0, 39.5),
    "SpO2": (94, 101, 90, 101),
    "Respiratory Rate": (12, 20, 8, 28),
}

# column name -> (label, direction that needs attention, min slope per reading)
TREND_RULES = {
    "heart_rate": ("Heart-rate", "up", 1.0),
    "temperature": ("Temperature", "up", 0.05),
    "spo2": ("SpO2", "down", 0.3),
    "resp_rate": ("Respiratory-rate", "up", 0.3),
}


def classify(value, limits):
    """Return 'Normal', 'Warning' or 'Critical' for one reading."""
    warn_low, warn_high, crit_low, crit_high = limits
    if value < crit_low or value > crit_high:
        return "Critical"
    if value < warn_low or value > warn_high:
        return "Warning"
    return "Normal"


def slope(values):
    """Linear regression slope = average change per reading."""
    if len(values) < 2:
        return 0.0
    return float(np.polyfit(np.arange(len(values)), values, 1)[0])


def trend_alerts(history, window=6):
    """Check the last `window` readings for a steady worrying trend."""
    alerts = []
    if history is None or len(history) < 3:
        return alerts
    recent = history.tail(window)
    for col, (label, direction, min_slope) in TREND_RULES.items():
        s = slope(recent[col].astype(float).values)
        if (direction == "up" and s >= min_slope) or (direction == "down" and s <= -min_slope):
            alerts.append(f"{label} trend requires attention. ({s:+.2f} per reading)")
    return alerts
