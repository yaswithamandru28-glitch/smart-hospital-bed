"""Smart Hospital Bed Monitoring System - Streamlit dashboard (PROTOTYPE).
Run with:  streamlit run app.py
Not a medical device. All hardware is simulated."""
import streamlit as st

import database
import fall_detection
import prediction
from bed_control import Headrest
from patient_data import PATIENTS

st.set_page_config(page_title="Smart Hospital Bed", page_icon="🏥", layout="wide")
database.init_db()

# ---- Session state: values that must survive Streamlit's reruns ----
if "bed" not in st.session_state:
    st.session_state.bed = Headrest()
if "emergency" not in st.session_state:
    st.session_state.emergency = None
if "rfid" not in st.session_state:
    st.session_state.rfid = "RFID1001"
bed = st.session_state.bed

# ---- Sidebar: RFID simulation and configurable thresholds ----
st.sidebar.title("🏥 Smart Bed")
rfid_input = st.sidebar.text_input("Scan RFID card ID", value=st.session_state.rfid,
                                   help="Try RFID1001, RFID1002 or RFID1003")
st.session_state.rfid = rfid_input.strip().upper()
patient = PATIENTS.get(st.session_state.rfid)

st.sidebar.subheader("Alert thresholds")
st.sidebar.caption("Configurable demo values - not medical advice.")
thresholds = {}
for name, (wl, wh, cl, ch) in prediction.DEFAULT_THRESHOLDS.items():
    with st.sidebar.expander(name):
        step = 0.1 if name == "Temperature" else 1.0
        wl = st.number_input("Warning low", value=float(wl), step=step, key=f"{name}wl")
        wh = st.number_input("Warning high", value=float(wh), step=step, key=f"{name}wh")
        cl = st.number_input("Critical low", value=float(cl), step=step, key=f"{name}cl")
        ch = st.number_input("Critical high", value=float(ch), step=step, key=f"{name}ch")
        thresholds[name] = (wl, wh, cl, ch)

st.title("🏥 Smart Hospital Bed Monitoring System")
st.caption("Prototype for demonstration. Not a medical diagnostic system.")

# ---- 2. Patient identification (stop early if unknown card) ----
st.header("Patient Identification")
if patient is None:
    st.error(f"Unknown RFID card '{st.session_state.rfid}'. Enter RFID1001, RFID1002 or RFID1003 in the sidebar.")
    st.stop()
st.success(f"Card recognised: {patient['name']}")
pid = patient["patient_id"]


def log(category, message):
    database.log_event(pid, category, message)


def raise_emergency(message, category):
    st.session_state.emergency = message
    log(category, message)


# ---- 9. Emergency alert (shown near the top so it is impossible to miss) ----
if st.session_state.emergency:
    st.error(f"🚨 EMERGENCY: {st.session_state.emergency}  -  Nurse assistance required.")
    if st.button("Acknowledge / Clear alert"):
        log("Emergency", "Alert acknowledged by staff")
        st.session_state.emergency = None
        st.rerun()

# ---- 1 & 3. Bed status + patient information ----
st.header("Hospital Bed Status")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Headrest angle", f"{bed.angle}°")
c2.metric("Headrest status", bed.status)
c3.metric("Room / Bed", patient["room"])
c4.metric("Emergency", "ACTIVE" if st.session_state.emergency else "None")

st.header("Patient Information")
i1, i2, i3, i4 = st.columns(4)
i1.metric("Name", patient["name"])
i2.metric("Patient ID", pid)
i3.metric("Age", patient["age"])
i4.metric("Room / Bed", patient["room"])
st.info(f"Medical info: {patient['medical_info']}")

# ---- 4. Headrest control ----
st.header("Headrest Control")
b1, b2, b3 = st.columns(3)
if b1.button("⬆️ Raise Headrest", use_container_width=True):
    log("Headrest", bed.raise_up()); st.rerun()
if b2.button("⬇️ Lower Headrest", use_container_width=True):
    log("Headrest", bed.lower()); st.rerun()
if b3.button("⏹ Stop", use_container_width=True):
    log("Headrest", bed.stop()); st.rerun()
st.progress(bed.angle / 90, text=f"Headrest angle: {bed.angle}° (0-90°)")

# ---- 5. Voice / command control ----
st.header("Voice / Command Control")
st.caption("Type a command (simulated voice): raise bed, lower bed, stop bed, emergency, call nurse")


def handle_command(text):
    """Turn a text command into an action. Unknown commands are just reported."""
    cmd = text.strip().lower()
    if not cmd:
        st.warning("Please enter a command.")
    elif "emergency" in cmd:
        raise_emergency("Emergency command received", "Emergency")
    elif "nurse" in cmd:
        raise_emergency("Nurse call requested", "Emergency")
    elif "raise" in cmd:
        log("Voice", f"'{cmd}' -> {bed.raise_up()}"); st.rerun()
    elif "lower" in cmd:
        log("Voice", f"'{cmd}' -> {bed.lower()}"); st.rerun()
    elif "stop" in cmd:
        log("Voice", f"'{cmd}' -> {bed.stop()}"); st.rerun()
    else:
        st.warning(f"Command not recognised: '{text}'")
    if st.session_state.emergency and cmd:
        st.rerun()


cmd_text = st.text_input("Command", key="cmd_text", placeholder="e.g. raise bed")
if st.button("Send command"):
    handle_command(cmd_text)

with st.expander("Optional: real microphone (needs SpeechRecognition + PyAudio + internet)"):
    if st.button("🎤 Listen"):
        try:
            import speech_recognition as sr
            rec = sr.Recognizer()
            with sr.Microphone() as mic:
                st.info("Listening...")
                audio = rec.listen(mic, timeout=5, phrase_time_limit=4)
            heard = rec.recognize_google(audio)
            st.write(f"Heard: **{heard}**")
            handle_command(heard)
        except ImportError:
            st.warning("Install SpeechRecognition and PyAudio to use the microphone.")
        except Exception as e:  # no mic, no internet, unclear speech...
            st.warning(f"Could not recognise speech: {e}")

# ---- 6. Vital signs ----
st.header("Vital Signs")
v1, v2, v3, v4 = st.columns(4)
hr = v1.slider("Heart Rate (BPM)", 20, 220, 78)
temp = v2.slider("Body Temperature (°C)", 30.0, 43.0, 36.8, 0.1)
spo2 = v3.slider("SpO₂ (%)", 50, 100, 98)
rr = v4.slider("Respiratory Rate (/min)", 4, 60, 16)

readings = {"Heart Rate": (hr, "BPM"), "Temperature": (temp, "°C"),
            "SpO2": (spo2, "%"), "Respiratory Rate": (rr, "/min")}
cols = st.columns(4)
for col, (name, (val, unit)) in zip(cols, readings.items()):
    status = prediction.classify(val, thresholds[name])
    icon = {"Normal": "🟢", "Warning": "🟡", "Critical": "🔴"}[status]
    col.metric(name, f"{val} {unit}")
    col.markdown(f"{icon} **{status}**")
    if status == "Critical":
        col.error("Critical reading")
    elif status == "Warning":
        col.warning("Warning reading")

if st.button("💾 Save this reading to history"):
    database.add_vitals(pid, hr, temp, spo2, rr)
    log("Vitals", f"Saved HR={hr}, Temp={temp}, SpO2={spo2}, RR={rr}")
    st.success("Reading saved.")
    if any(prediction.classify(v, thresholds[n]) == "Critical" for n, (v, _) in readings.items()):
        raise_emergency("Critical vital-sign reading", "Emergency")
        st.rerun()

# ---- 7. Fall detection ----
st.header("Fall Detection")
posture = st.selectbox("Patient posture (simulated)", fall_detection.POSTURES)
if st.button("Check posture"):
    is_fall, msg = fall_detection.check_posture(posture)
    if is_fall:
        raise_emergency(msg, "Fall")
        st.rerun()
    st.success(msg)

with st.expander("Optional: camera-based check (needs opencv-python + mediapipe)"):
    photo = st.camera_input("Take a picture")
    if photo is not None:
        result = fall_detection.analyze_camera_image(photo.getvalue())
        if result is None:
            st.warning("Could not analyse image (libraries missing or no person found).")
        elif result == "Possible Fall":
            raise_emergency("Possible fall detected by camera", "Fall")
            st.rerun()
        else:
            st.success(f"Camera result: {result}")
st.caption("Prototype only - not medically accurate.")

# ---- 8. Predictive alerts ----
st.header("Predictive Alerts")
st.caption("Prototype alert system based on simple trends, not a medical diagnostic system.")
history = database.get_vitals_history(pid)
alerts = prediction.trend_alerts(history)
if alerts:
    for a in alerts:
        st.warning(a)
else:
    st.success("No concerning trends found in recent readings.")
if not history.empty:
    chart_data = history.set_index("time")
    t1, t2 = st.columns(2)
    t1.line_chart(chart_data[["heart_rate", "resp_rate"]])
    t2.line_chart(chart_data[["temperature", "spo2"]])

# ---- 10. Activity / alert history ----
st.header("Activity / Alert History")
log_df = database.get_log()
if log_df.empty:
    st.info("No activity yet.")
else:
    st.dataframe(log_df, use_container_width=True, hide_index=True)
