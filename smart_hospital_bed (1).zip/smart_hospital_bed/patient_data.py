"""Sample (dummy) patient data. Replace with a real hospital database later."""

# RFID card ID -> patient record
PATIENTS = {
    "RFID1001": {"patient_id": "P001", "name": "Ravi Kumar", "age": 54,
                 "room": "Room 101 / Bed A", "medical_info": "Type 2 diabetes, hypertension"},
    "RFID1002": {"patient_id": "P002", "name": "Anita Sharma", "age": 67,
                 "room": "Room 102 / Bed B", "medical_info": "Post-surgery recovery, mild asthma"},
    "RFID1003": {"patient_id": "P003", "name": "Suresh Reddy", "age": 41,
                 "room": "Room 103 / Bed A", "medical_info": "Fracture (left leg), no known allergies"},
}

# Per-reading change used to create demo history: (heart rate, temp, SpO2, resp rate)
# P002 deliberately trends in a worrying direction so predictive alerts show up.
SEED_TRENDS = {
    "P001": (0.0, 0.0, 0.0, 0.0),
    "P002": (2.5, 0.12, -0.6, 0.4),
    "P003": (0.3, 0.0, 0.0, 0.0),
}
BASE_VITALS = (76, 36.8, 98, 16)  # starting values for the demo history
