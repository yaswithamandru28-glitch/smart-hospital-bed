"""Fall detection: a simulated posture check plus an optional camera check.
PROTOTYPE ONLY - not medically accurate or validated."""

POSTURES = ["Normal", "Sitting", "Lying", "Possible Fall"]


def check_posture(posture):
    """Return (is_fall, message) for a posture chosen in the dashboard."""
    if posture not in POSTURES:
        return False, "Unknown posture"
    if posture == "Possible Fall":
        return True, "Possible fall detected!"
    return False, f"Posture: {posture}"


def analyze_camera_image(image_bytes):
    """Optional: guess posture from a photo using OpenCV + MediaPipe.
    Returns a posture string, or None if libraries/pose are unavailable.
    Idea: if the body is wider than it is tall, the person is probably lying/fallen."""
    try:
        import cv2
        import numpy as np
        import mediapipe as mp
    except ImportError:
        return None
    img = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        return None
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    with mp.solutions.pose.Pose(static_image_mode=True) as pose:
        result = pose.process(rgb)
    if not result.pose_landmarks:
        return None
    xs = [p.x for p in result.pose_landmarks.landmark]
    ys = [p.y for p in result.pose_landmarks.landmark]
    width, height = max(xs) - min(xs), max(ys) - min(ys)
    return "Possible Fall" if width > 1.2 * height else "Normal"
